# first-app-academy-website
This is the first public repository made during App Academy Open. It is a simple website with multiple pages.
