

\# index.html "home" \#

\# **color theme ideas** \#

Color Theme:
white: #fff
footer: #232323
footer columns: #f6f7f7
Gray header: #f6f7f7
text: #000

rolex uses a linear gradient of green from dark on left to light on right.

rolex black text: #212121
olevs blue face dark: #023d6a
olevs blue face bright: #0496db

font-family: fredoka, sans-serif;

\# **end color theme ideas** \#

\# nav bar \#

---
| home  contact us  education   popular watches |
---
\# overlay h1 with text gradient over main image \#
# Automatic Watches
![olevs 6670 image](https://olevswatches.com/wp-content/uploads/2022/08/OLEVS-Watch-6670-Fully-Automatic-Mechanical-Movement-BROWN-BLUE.png)

\# 3 columns of text with h2 headers

## Aesthetics   Connect With History    Precision Engineering

paragraph about aesthetics    paragraph about history   paragraph about engineering

---
Page 2, contact.html

\# nav bar

| home  contact us  education   popular watches |
---
\# contain everything in a fieldset

| name | email |
--
| text input | email input |
---
| q subject | \# two wide
---
| q text input | \# two wide
---
| enter your comment or q | \# two wide
---
| textarea for q | \# two wide
---
| submit button | subscribe checkbox |
---
---
page 3, education.html

\# nav bar

---
| home  contact us  education   popular watches |
---

# Useful Horological Resources

\# One unordered list of links to 5 other websites

---
page 4, popular-watches.html
---
| home  contact us  education   popular watches |
---
# Popular Automatic Watches

\# grid 2 rows & 3 columns, 6 watches with a label for each image \#

\# each label in same flex-direction: column div with its watch image \#

\# example of watch div \#
---
| watch label |
---
| watch image |
---

\# grid layout \#

---
| watch div 1 | watch div 2 | watch div 3 |
---
| watch div 4 | watch div 5 | watch div 6 |
---

\# each image is wrapped in an anchor element \#
